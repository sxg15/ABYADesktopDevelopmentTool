# ABYA 开发文档生成 Skill 完整包

这是 `abya-gameplay-brief`「从参考到开发文档」的完整离线快照，包含 Skill 本体、全部内置素材、规范说明、导出脚本、底层规则台账和蜡笔纸艺特效库。另附飞书操作 Skill，以及规范引用的原始背景纹样参考视频。

## 从这里开始

1. 阅读[安装与使用说明](docs/使用说明.md)。
2. 将 `skills/` 下的三个文件夹一起复制到目标工具的 Skill 目录，保留同级关系。
3. 用 `$abya-gameplay-brief` 加上玩法想法、图片或已有文档发起任务。
4. 飞书同步需要目标环境已安装的 CLI 或连接器，以及有相应文档权限的登录身份；按需安装 `integrations/skills/` 中的四个辅助 Skill。

## 文件入口

| 内容 | 入口 |
|---|---|
| 主 Skill | [SKILL.md](skills/abya-gameplay-brief/SKILL.md) |
| 全部配套素材与各自职责 | [素材与文件索引](docs/素材与文件索引.md) |
| 安装、调用、导出示例与检查 | [使用说明](docs/使用说明.md) |
| 依赖、来源路径映射和快照边界 | [依赖与迁移说明](docs/依赖与迁移说明.md) |
| 当前 UI 唯一规格 | [play-ui-layout.md](skills/abya-gameplay-brief/references/play-ui-layout.md) |
| 开局 321 | [start-countdown.md](skills/abya-gameplay-brief/references/start-countdown.md) |
| 生效规则与旧稿迁移记录 | [ledger.json](skills/abya-foundation-rule-maintenance/state/ledger.json) |
| 特效库 | [SKILL.md](skills/abya-crayon-paper-effects/SKILL.md) |
| 飞书同步 | [同步契约](skills/abya-gameplay-brief/references/abya-input-contract.md) |

原始 Skill 和素材按字节保存；本次整理增加的是包级说明、索引、示例和校验工具。缓存文件未打包。历史参考仍在原目录，是否生效以现行规范为准。

此 ZIP 用于安装和备份 Skill。制作端接收的单玩法输入包另由主 Skill 生成，不应直接把本 ZIP 当作某一玩法的开发输入。

解压后运行 `py -3 scripts/verify_bundle.py`（或 `python scripts/verify_bundle.py`）检查 SHA-256。打包时的检查结果见 [validation.json](validation.json)。
