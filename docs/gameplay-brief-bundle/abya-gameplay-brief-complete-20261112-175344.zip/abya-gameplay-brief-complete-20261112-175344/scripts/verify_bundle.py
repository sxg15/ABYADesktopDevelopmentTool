"""Verify this extracted bundle against manifest.json (standard library only)."""
from pathlib import Path
import hashlib
import json
import sys

def main():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / 'manifest.json').read_text(encoding='utf-8'))
    errors = []
    expected = set()
    for item in manifest['files']:
        name = item['path']
        path = root / name
        expected.add(name)
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            errors.append('Unsafe path: ' + name)
            continue
        if not path.is_file():
            errors.append('Missing file: ' + name)
            continue
        data = path.read_bytes()
        if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
            errors.append('Content mismatch: ' + name)
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*')
              if p.is_file() and '__pycache__' not in p.parts and p.suffix not in {'.pyc', '.pyo'}}
    extras = sorted(actual - expected - {'manifest.json'})
    print(json.dumps({'ok': not errors, 'checkedFiles': len(expected),
                      'errors': errors, 'extraFiles': extras}, ensure_ascii=False, indent=2))
    return 1 if errors else 0

if __name__ == '__main__':
    sys.exit(main())
