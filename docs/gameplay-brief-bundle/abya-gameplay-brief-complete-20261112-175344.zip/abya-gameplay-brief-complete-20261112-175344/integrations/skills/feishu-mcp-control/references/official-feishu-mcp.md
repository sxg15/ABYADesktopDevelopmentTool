# Official Feishu MCP And CLI Reference

This reference summarizes verified behavior from the official Feishu/Lark documentation for future Feishu automation tasks.

## Sources

- MCP overview: https://open.feishu.cn/document/uAjLw4CM/ukTMukTMukTM/mcp_integration/mcp_introduction
- Remote MCP tools: https://open.larkoffice.com/document/mcp_open_tools/supported-tools
- Personal remote MCP setup: https://open.larkoffice.com/document/mcp_open_tools/end-user-call-remote-mcp-server
- Developer remote MCP setup: https://open.feishu.cn/document/mcp_open_tools/developers-call-remote-mcp-server
- OpenAPI MCP overview: https://open.larkoffice.com/document/mcp_open_tools/mcp-overview
- Feishu CLI overview: https://open.feishu.cn/document/mcp_open_tools/feishu-cli-let-ai-actually-do-your-work-in-feishu
- OpenAPI MCP tool list: https://github.com/larksuite/lark-openapi-mcp/blob/main/docs/reference/tool-presets/tools-zh.md

## Mode Selection

Feishu officially describes three practical paths:

- Feishu CLI: recommended for broad Feishu automation. It can cover messages, groups, docs, drive, sheets, Base, calendar, meetings, minutes, email, tasks, wiki, contacts, slides, whiteboard, OKR, approvals, and attendance depending on app capabilities and permissions.
- Remote MCP: recommended MCP path when using official hosted MCP, currently focused on cloud-document scenarios for end users. Personal remote MCP service URLs are credential-like and new URLs created from 2026-02-24 expire after 7 days.
- Local OpenAPI MCP: not recommended for ordinary end users. It requires developer deployment but can expose broad Feishu server OpenAPI tools.

## Remote MCP Cloud-Document Tools

Common tools:

- `search-user`: search visible users by keyword. UAT only; cannot search external enterprise or departed users.
- `get-user`: get current or visible user identity details. UAT/TAT; TAT depends on contacts visibility.
- `fetch-file`: fetch binary content by `file_token`. File size limit is 5 MB and the acting user must have download permission.

Cloud document tools:

- `search-doc`: search doc/docx cloud documents. UAT only.
- `create-doc`: create a cloud document in My Docs or a wiki node; use `update-doc` for long continuation.
- `fetch-doc`: fetch a cloud document by link or document ID; long documents may need paginated/segmented reads.
- `update-doc`: append, replace, or insert content; link anchors are not supported for positioning.
- `list-docs`: list documents under a wiki node; sub-wikis must be traversed by the agent.
- `get-comments`: read full-document and selected-text comments; supports emoji/text/doc comments, not comment images.
- `add-comments`: add full-document comments only; selected-text comments and image upload in comments are not supported.

Cloud-document limitations to remember:

- `search-doc` only searches doc/docx.
- `create-doc` cannot insert existing Base, spreadsheets, OKR, tasks, calendar events, Feishu Project objects, document widgets, sync blocks, old flowcharts, or old mind notes.
- `fetch-doc` cannot read Base, spreadsheets, OKR, tasks, group cards, calendar cards, Feishu Project content, old flowcharts, or old mind notes embedded in documents.

## Developer Remote MCP

Endpoint:

```text
POST https://mcp.feishu.cn/mcp
Content-Type: application/json
X-Lark-MCP-UAT: <user_access_token>
```

or:

```text
POST https://mcp.feishu.cn/mcp
Content-Type: application/json
X-Lark-MCP-TAT: <tenant_access_token>
```

Include `X-Lark-MCP-Allowed-Tools: toolname1,toolname2` whenever tools should be discoverable. Without this header, the AI cannot discover or call tools.

Supported MCP methods:

- `initialize`: establish a session and validate credentials.
- `tools/list`: list available tools constrained by credentials and `X-Lark-MCP-Allowed-Tools`.
- `tools/call`: call a named tool with `params.name` and `params.arguments`.

Official caution: remote MCP tool input and output schemas may change. Inspect `tools/list` or current API docs before writing schema-dependent code.

## Permissions

For developer remote MCP, create a self-built app, apply for the API scopes required by the selected tools, and obtain either UAT or TAT.

Representative cloud-document scopes:

- Search docs: `search:docs:read`, `wiki:wiki:readonly`
- Create/update docs: `docx:document:create`, `docx:document:write_only`, `docx:document:readonly`, `wiki:node:read`, `wiki:node:create`, plus media/whiteboard scopes when inserting those assets
- Fetch docs: `docx:document:readonly`, and possibly task/chat read scopes for embedded references
- Comments: `docs:document.comment:read` or `docs:document.comment:create`
- User search/profile: contact scopes such as `contact:user:search`, `contact:user.base:readonly`, `contact:contact.base:readonly`

With TAT, the app must also have access to target docs or wiki spaces. With UAT, access follows the current user's own Feishu permissions.

## Error Handling

Common JSON-RPC/HTTP failures:

- 400 `-32700` parse error: invalid JSON.
- 400 `-32600` invalid request: malformed JSON-RPC body, missing `jsonrpc`, `method`, `id`, or invalid params shape.
- 404 `-32601` method not found: wrong MCP method or tool outside allowed list.
- 400 `-32602` invalid params: inspect `error.message`.
- 500 `-32603` internal error: retry briefly, then escalate with redacted request time/parameters.
- 429 `-32030` rate limited: reduce request rate.
- 401 `-32011` UAT/TAT required: missing auth header.
- 400 `-32003` invalid or expired GrantToken/UAT/TAT.
- 400 `-32042` invalid content type: use `application/json`.

Tool execution can fail inside a 200 response by returning `result.isError: true`; check content text for the tool-level error and log ID.

## CLI Setup And Operations

Installation:

```text
npx @larksuite/cli@latest install
```

After install/config changes, restart the AI tool so MCP/skills are loaded.

Useful commands:

```text
lark-cli config init
lark-cli auth login
lark-cli auth status
lark-cli auth check
lark-cli auth login --domain <domain>
lark-cli auth login --scope "<missing_scope>"
lark-cli auth logout
lark-cli help
lark-cli <command> --help
```

Profiles:

```text
lark-cli config init --new --name bot-reader
lark-cli profile list
lark-cli profile use bot-reader
lark-cli --profile bot-reader <command>
```

Prefer `--profile` for one command in concurrent automation because changing the default profile is persistent.
