---
name: feishu-mcp-control
description: Control Feishu/Lark work through the official Feishu CLI or Feishu MCP, including setup checks, document operations, messaging, calendar, sheets, Base, tasks, and related permission-sensitive workflows.
---

# Feishu MCP Control

Use this skill whenever the user asks Codex to operate Feishu/Lark, read or write Feishu cloud documents, search Feishu content, manage messages, calendars, sheets, Base, tasks, email, approvals, or configure Feishu MCP/CLI access.

## Preferred Access Path

- Prefer the official Feishu CLI for broad Feishu automation. The official remote MCP Token link is being phased out, and new personal remote MCP service URLs created on or after 2026-02-24 are valid for 7 days.
- Use official remote MCP when the user explicitly provides or asks for a remote MCP URL, or when the target client only supports MCP and CLI is not available.
- Use the local OpenAPI MCP mode only for developer-controlled deployments or when the user explicitly asks for local MCP/OpenAPI coverage beyond the remote cloud-document toolset.

## Before Acting

- Check whether `lark-cli` is installed and authenticated before promising live Feishu operations.
- If a task needs the user's personal data or should act as the user, verify user authorization with `lark-cli auth status` when CLI is available. Use `lark-cli auth login` only when the user asks to configure authorization or confirms an auth flow.
- For app-identity work, confirm the intended app/profile. Use `lark-cli profile list` to inspect configured profiles, and prefer `lark-cli --profile <name> ...` for concurrent or automation tasks.
- Treat remote MCP server URLs, UAT, TAT, app secrets, and copied JSON config as credentials. Do not print them back, save them into user-facing files, or expose them in logs.
- Ask for confirmation before sending messages, emails, calendar invitations, changing permissions, deleting/moving content, approving/rejecting workflows, or making broad batch edits. Read-only retrieval and local drafting do not need extra confirmation unless the user requests it.

## Codex MCP Setup

- A Feishu skill does not install or enable an MCP server. Verify the connection separately with `codex mcp list` or the current task's exposed tools.
- Prefer a stdio launcher that reads credentials from an ignored local file or OS credential store. Do not pass an app secret through `codex mcp add --env`, because the configured value is persisted in Codex configuration.
- Enable only the exact tools required for the workflow. Adding a server does not make its tools appear in an already-running task; verify it in a new task after configuration.

## Tooling Notes

- For current-user cloud-document MCP, the supported remote tools are `search-user`, `get-user`, `fetch-file`, `search-doc`, `create-doc`, `fetch-doc`, `update-doc`, `list-docs`, `get-comments`, and `add-comments`.
- Remote MCP currently focuses on cloud documents. It cannot read or create every Feishu object; notable cloud-document limits include unsupported embedded Base, sheets, OKR, tasks, calendar cards, Feishu Project, old flowcharts, old mind notes, widgets, and sync blocks.
- For developer remote MCP calls, use `https://mcp.feishu.cn/mcp` with JSON-RPC 2.0 over POST. Include `Content-Type: application/json`, exactly one of `X-Lark-MCP-UAT` or `X-Lark-MCP-TAT`, and `X-Lark-MCP-Allowed-Tools` with comma-separated tool names; without the allowed-tools header, tools cannot be discovered or called.
- Developer remote MCP supports `initialize`, `tools/list`, and `tools/call`. Do not rely on stable tool input/output schema details because the official docs warn they may change.
- For OpenAPI MCP tool names, use the `biz.version.resource.method` convention from the Node SDK method name, for example `im.v1.message.create`.
- When a task requires broad OpenAPI coverage, inspect the official tool list or the specific API documentation before selecting tools; grey-release APIs and image/file upload-download APIs may not be available in OpenAPI MCP.

## Common CLI Commands

- Install/configure: `npx @larksuite/cli@latest install`
- Initialize app config: `lark-cli config init`
- User login: `lark-cli auth login`
- Check login: `lark-cli auth status`
- Check permissions: `lark-cli auth check`
- Request domain-specific auth: `lark-cli auth login --domain <domain>`
- Request missing scope after a permission error: `lark-cli auth login --scope "<missing_scope>"`
- Show help: `lark-cli help` or `lark-cli <command> --help`
- Query command schema: use the CLI `schema` command when exact parameters are needed.

## References

Read [references/official-feishu-mcp.md](references/official-feishu-mcp.md) when configuring access, choosing between CLI/remote MCP/local OpenAPI MCP, handling MCP errors, or checking supported cloud-document tools and permissions.
